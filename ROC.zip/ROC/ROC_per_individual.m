n_iterations = 1000;       
conf_level = 95;           

data = csvread('data.csv');
pos_labels = data(:, 1);   %1=medial-lateral；2=anterior-posterior
mem_labels = data(:, 3);    
subject_ids = data(:, 4);   
unique_subjects = unique(subject_ids);


original_model = fitglm(pos_labels, mem_labels, 'Distribution', 'binomial');
pred_probs = predict(original_model, pos_labels);

[fpr_orig, tpr_orig, ~, original_auc] = perfcurve(mem_labels, pred_probs, 1);

if fpr_orig(1) > 0
    fpr_orig = [0; fpr_orig];
    tpr_orig = [0; tpr_orig];
end
if tpr_orig(end) < 1
    fpr_orig = [fpr_orig; 1];  
    tpr_orig = [tpr_orig; 1]; 
end


fpr_grid = linspace(0, 1, 1000);
perm_rocs = zeros(n_iterations, length(fpr_grid));

for iter = 1:n_iterations
   
    shuffled_pos = pos_labels;
    for s = 1:length(unique_subjects)
        subj_idx = find(subject_ids == unique_subjects(s));
        if numel(subj_idx) > 1
            shuffled_pos(subj_idx) = shuffled_pos(subj_idx(randperm(numel(subj_idx))));
        end
    end
    
    perm_model = fitglm(shuffled_pos, mem_labels, 'Distribution', 'binomial');
    perm_probs = predict(perm_model, shuffled_pos);
    
    [fpr_perm, tpr_perm, ~] = perfcurve(mem_labels, perm_probs, 1);
    
    if isempty(fpr_perm)
        fpr_perm = [0 1];
        tpr_perm = [0 1];
    else
        if fpr_perm(1) > 0
            fpr_perm = [0; fpr_perm];
            tpr_perm = [0; tpr_perm];
        end
        if fpr_perm(end) < 1
            fpr_perm = [fpr_perm; 1];
            tpr_perm = [tpr_perm; 1];
        elseif fpr_perm(end) == 1 && tpr_perm(end) < 1
            tpr_perm(end) = 1;
        end
    end
    
    [fpr_perm, idx] = unique(fpr_perm, 'stable');
    tpr_perm = tpr_perm(idx);
  
    perm_rocs(iter,:) = interp1(fpr_perm, tpr_perm, fpr_grid, 'linear', 'extrap');
end

ci_low = prctile(perm_rocs, (100-conf_level)/2, 1);
ci_high = prctile(perm_rocs, 100 - (100-conf_level)/2, 1);
mean_perm_roc = mean(perm_rocs,1);


p_value = sum(mean(perm_rocs,2) >= original_auc) / n_iterations;

figure('Position', [100, 100, 700, 600]); 
hold on;

stairs(fpr_orig, tpr_orig, 'b-', 'LineWidth', 4);

fill([fpr_grid, fliplr(fpr_grid)], [ci_high, fliplr(ci_low)], ...
    [0.5 0.5 0.5], 'EdgeColor', 'none', 'FaceAlpha', 0.2);


mean_perm_roc = mean(perm_rocs, 1);
plot(fpr_grid, mean_perm_roc, 'k-', 'LineWidth', 2);


text(0.6, 0.12, sprintf('AUC = %.3f', original_auc), ...
    'FontSize', 24, 'FontWeight', 'bold', 'Color', 'k');
p_value = sum(mean(perm_rocs,2) >= original_auc)/n_iterations;
text(0.38, 0.99, sprintf('p = %.3f', p_value), ...
    'FontSize', 24, 'FontWeight', 'bold');

xlabel('False Positive Rate', 'FontSize', 24, 'FontWeight', 'bold');
ylabel('True Positive Rate', 'FontSize', 24, 'FontWeight', 'bold');
set(gca, 'FontSize', 24, 'FontWeight', 'bold','LineWidth', 2, 'Box', 'off');
axis([0 1 0 1]);
grid off;
hold off;
